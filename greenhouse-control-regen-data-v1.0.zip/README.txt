Greenhouse control -- regeneration data and analysis scripts
=============================================================
Companion archive for the manuscript (MDPI Agronomy submission, branch
tier1-path-a-consolidation, commit 3177e14).

Contents
--------
regen/*.py          experiment runners and analysis scripts
regen/results/      per-run CSVs for all benchmark controllers, the
                    library ladder (raw / no_cross / physics_no_tuboil /
                    physics), kappa ladders, and analysis summaries

Key entry points
----------------
regen/run_regen.py        reproduces the benchmark runs
regen/analyze_notuboil.py paired Wilcoxon/Holm statistics for the
                          17-feature (no t_in*uBoil) library probe
regen/kappa_notuboil.py   condition-number ladder for the probe
regen/make_tables.py      regenerates the manuscript tables

All numbers quoted in the manuscript carry %% provenance comments that
name the exact file and column they were read from.

Packaged: 2026-08-18
